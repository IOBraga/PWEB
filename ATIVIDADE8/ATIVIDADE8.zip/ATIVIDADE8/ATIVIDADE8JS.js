// array para opinioes
var opinioes = [];

// Variáveis para cálculos
var totalIdade = 0;
var idadeMaisVelha = 0;
var idadeMaisNova = Infinity;
var quantidadePessimo = 0;
var quantidadeOtimoBom = 0;
var quantidadeMulheres = 0;
var quantidadeHomens = 0;

// Loop para coletar os dados
for (var i = 0; i < 45; i++) {
    var idade = parseInt(prompt("Informe a idade da pessoa " + (i+1) + ":"));
    var sexo = prompt("Informe o sexo da pessoa " + (i+1) + " (M para masculino, F para feminino):");
    var opiniao = parseInt(prompt("Informe a opinião da pessoa " + (i+1) + " sobre o filme com um número de 1 a 4, sendo:" +
        "\n1 - péssimo" +
        "\n2 - regular" +
        "\n3 - bom" +
        "\n4 - ótimo"));

    // Somando a idade para calcular a média
    totalIdade += idade;

    // Verificando a idade mais velha e mais nova
    idadeMaisVelha = Math.max(idade, idadeMaisVelha);
    idadeMaisNova = Math.min(idade, idadeMaisNova);

    // Contando a quantidade de pessoas que responderam péssimo
    if (opiniao === 1) {
        quantidadePessimo++;
    }

    // Contando a quantidade de pessoas que responderam ótimo e bom
    if (opiniao === 3 || opiniao === 4) {
        quantidadeOtimoBom++;
    }

    // Contando a quantidade de mulheres e homens
    if (sexo.toUpperCase() === "M") {
        quantidadeHomens++;
    } else if (sexo.toUpperCase() === "F") {
        quantidadeMulheres++;
    }
}

// Calculando a média de idade
var mediaIdade = totalIdade / 45;

// Calculando a porcentagem de pessoas que responderam ótimo e bom
var porcentagemOtimoBom = (quantidadeOtimoBom / 45) * 100;

// Exibindo os resultados em um alerta
var mensagem = "Resultados da Pesquisa:\n\n";
mensagem += "Média de idade: " + mediaIdade.toFixed(2) + " anos\n";
mensagem += "Idade da pessoa mais velha: " + idadeMaisVelha + " anos\n";
mensagem += "Idade da pessoa mais nova: " + idadeMaisNova + " anos\n";
mensagem += "Quantidade de pessoas que responderam péssimo: " + quantidadePessimo + "\n";
mensagem += "Porcentagem de pessoas que responderam ótimo e bom: " + porcentagemOtimoBom.toFixed(2) + "%\n";
mensagem += "Número de mulheres que responderam ao questionário: " + quantidadeMulheres + "\n";
mensagem += "Número de homens que responderam ao questionário: " + quantidadeHomens + "\n";

alert(mensagem);


